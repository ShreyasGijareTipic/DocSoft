import React from "react";

 const Billing = () =>{
    return(
        <>
        <h1>hsgdhdjh</h1>
        </>
    )
}
export default Billing;