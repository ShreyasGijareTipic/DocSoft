import React from 'react'
import CIcon from '@coreui/icons-react'
import {
  cilBell,
  cilCalculator,
  cilChartPie,
  cilCursor,
  cilDescription,
  cilDrop,
  cilNotes,
  cilPencil,
  cilPuzzle,
  cilSpeedometer,
  cilStar,
  cilUserPlus,
  cilStorage,
} from '@coreui/icons'
import { CNavGroup, CNavItem, CNavTitle,  } from '@coreui/react'

const _nav = [


  {
    component: CNavItem,
    name: 'Dashboard',
    to: '/theme/docDashboard',
    icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  },
  {
    component: CNavItem,
    name: 'Create Bill',
    to: '/theme/bills',
    icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  },
  {
    component: CNavItem,
    name: 'Create Prescription',
    to: '/theme/prescriptionForm',
    icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  },
  {
    component: CNavItem,
    name: 'Patients',
    to: '/theme/patient',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,
  }, 
  {
    component: CNavItem,
    name: 'Bills',
    to: '/theme/billstable',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Medicines',
    to: '/theme/medicines',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Time Slots',
    to: '/theme/timeslots',
    icon: <CIcon icon={cilStorage} customClassName="nav-icon" />,
  },
  {
    component: CNavItem,
    name: 'Clinic Register',
    to: '/register/ClinicRegister',
    icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  },
  // {
  //   component: CNavItem,
  //   name: 'User Register',
  //   to: '/register/Register',
  //   icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  // },
  {
    component: CNavItem,
    name: 'Clinics',
    to: '/register/WhatsappClinicRegister',
    icon: <CIcon icon={cilUserPlus} customClassName="nav-icon" />,
    
  },
  
  
 
 
]

export default _nav
