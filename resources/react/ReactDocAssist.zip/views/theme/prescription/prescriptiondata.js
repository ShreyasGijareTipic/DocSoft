import React from 'react'

export default function prescriptiondata() {


  return (
    <div>
      <h1>jsdsdsjsj</h1>
    </div>
  )
}
